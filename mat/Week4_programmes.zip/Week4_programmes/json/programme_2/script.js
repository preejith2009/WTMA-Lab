// Function to fetch and display student data from the JSON file
function displayStudentData() {
    fetch('students.json')  // Fetch the JSON file
        .then(response => response.json())  // Parse the JSON
        .then(data => {
            const studentsTable = document.getElementById('students');  // Get the table body element

            // Clear any existing data
            studentsTable.innerHTML = '';

            // Loop through the student data and create table rows
            for (let i = 0; i < data.length; i++) {
                const student = data[i];

                // Create a new table row
                const row = document.createElement('tr');

                // Create and append table data cells for each property
                const studentNumberCell = document.createElement('td');
                studentNumberCell.textContent = student.student_id;
                row.appendChild(studentNumberCell);

                const nameCell = document.createElement('td');
                nameCell.textContent = student.name;
                row.appendChild(nameCell);

                const ageCell = document.createElement('td');
                ageCell.textContent = student.age;
                row.appendChild(ageCell);

                const gradeCell = document.createElement('td');
                gradeCell.textContent = student.grade;
                row.appendChild(gradeCell);

                const emailCell = document.createElement('td');
                emailCell.textContent = student.email;
                row.appendChild(emailCell);

                const addressCell = document.createElement('td');
                addressCell.textContent = student.address;
                row.appendChild(addressCell);

                const phoneCell = document.createElement('td');
                phoneCell.textContent = student.phone;
                row.appendChild(phoneCell);

                // Append the new row to the table body
                studentsTable.appendChild(row);
            }
        })
        .catch(error => console.error('Error loading the JSON data:', error));
}

// Event listener for the 'Display Student Data' button
document.getElementById('fetchData').addEventListener('click', displayStudentData);


function clearTable() {
    const tableBody = document.querySelector('#studentsTable tbody');
    tableBody.innerHTML = '';  // Clear all rows in the table body
}

// Example usage: Call this function when a "Clear Table" button is clicked
document.getElementById('clearTableBtn').addEventListener('click', clearTable);

