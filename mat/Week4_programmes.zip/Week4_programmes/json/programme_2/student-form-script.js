let students = [];  // Array to hold student details

document.getElementById('studentForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form from submitting

    // Collect form data for a new student
    const studentData = {
        student_id: document.getElementById('student_id').value,
        name: document.getElementById('name').value,
        age: document.getElementById('age').value,
        grade: document.getElementById('grade').value,
        email: document.getElementById('email').value,
        address: document.getElementById('address').value,
        phone: document.getElementById('phone').value
    };

    // Add the new student data to the students array
    students.push(studentData);

    // Reset form fields for next input
    document.getElementById('studentForm').reset();

    // Show the "Download student.json" button once we have at least one student
    document.getElementById('downloadButton').style.display = 'inline-block';
});

// Download all students' data as student.json
document.getElementById('downloadButton').addEventListener('click', function() {
    // Convert the students array to a JSON string
    const jsonData = JSON.stringify(students, null, 2); // Formatting for readability

    // Create a Blob with the JSON data and set the file name
    const blob = new Blob([jsonData], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'students.json';

    // Trigger the download
    link.click();
});
